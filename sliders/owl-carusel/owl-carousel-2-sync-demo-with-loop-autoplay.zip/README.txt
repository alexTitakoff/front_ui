A Pen created at CodePen.io. You can find this one at http://codepen.io/washaweb/pen/KVRxRW.

 Owl Carousel 2 with 2 synced carousel and synced navigation
loop, autoplay are enabled, define number of item globaly, 
Added inline SVG arrows for the the first carousel prev/next navigation